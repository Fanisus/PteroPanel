let adminVisiblilities = []
let sidebar_size_toggle_state = "large"
function sidebar_size_toggle() {
    console.log("cliecks");
    if (sidebar_size_toggle_state === "large") {
        
    }
    else if (sidebar_size_toggle_state === "small") {

    }
}